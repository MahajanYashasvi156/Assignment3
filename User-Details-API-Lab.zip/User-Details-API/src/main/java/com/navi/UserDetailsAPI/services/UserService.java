package com.navi.UserDetailsAPI.services;
import com.navi.UserDetailsAPI.entity.User;
import com.navi.UserDetailsAPI.repository.UserRepositoryImp.UserRepository;
import com.navi.UserDetailsAPI.repository.UserRepositoryImp.UserRepositoryImp;
import org.springframework.stereotype.Service;

/**
 * The UserService interface represents the contract for managing user-related operations.
 * Implementations of this interface provide methods to create and fetch user information.
 */
@Service
public class UserService {

    private final UserRepository userRepository;
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Creates a new user with the given username.
     *
     * @param username The username of the new user to be created.
     * @return The User object representing the newly created user.
     */

    public User createUser(User user) {
        return userRepository.createUser(user);
    }


}
