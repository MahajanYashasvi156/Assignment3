package com.navi.UserDetailsAPI.services;
package com.navi.UserDetailsAPI.repository.UserRepository;
import com.navi.UserDetailsAPI.entity.User;
import com.navi.UserDetailsAPI.repository.UserRepository;
import org.springframework.stereotype.Service;

/**
 * The UserService interface represents the contract for managing user-related operations.
 * Implementations of this interface provide methods to create and fetch user information.
 */
@Service
public class UserService {

    private final UserRepository userRepository;
    /**
     * Creates a new user with the given username.
     *
     * @param username The username of the new user to be created.
     * @return The User object representing the newly created user.
     */
    public static User createUser(User user) {
        return userRepository.createUser(user);
    }


}
