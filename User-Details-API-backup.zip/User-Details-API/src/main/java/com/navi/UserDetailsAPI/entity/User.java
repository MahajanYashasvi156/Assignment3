package com.navi.UserDetailsAPI.entity;


import java.util.ArrayList;

/**
 * The User class represents a basic user entity with properties such as username, full name, and email,address.
 * This class provides methods to get and set these properties.
 */
public class User
{
    private String name;
    private String email;

//    private List<String> address;
    private String phoneNumber;
    public User(String name, String email,String phoneNumber) {
        this.name =  name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    /**
     * Constructs a new User object with the specified username.
     *
     * @param name The name for the user.
     */
    public User(String name) {
        this.name = name;
    }

    /**
     * Retrieves the username of the user.
     *
     * @return The username of the user.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the username of the user.
     *
     * @param name The new username for the user.
     */
    public void setUsername(String name) {
        this.name = name;
    }


    /**
     * Retrieves the email address of the user.
     *
     * @return The email address of the user.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email The new email address for the user.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Retrieves the phone number of the user.
     *
     * @return The phone number of the user.
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the phoneNumber of the user.
     *
     * @param phoneNumber The new phone number for the user.
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
