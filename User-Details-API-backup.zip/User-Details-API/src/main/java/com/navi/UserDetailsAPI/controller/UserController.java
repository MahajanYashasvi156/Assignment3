package com.navi.UserDetailsAPI.controller;

import com.navi.UserDetailsAPI.entity.User;
import com.navi.UserDetailsAPI.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/CreateUser")
    public ResponseEntity<?> createUser(@RequestBody User user)
    {
        if (!isValidPhoneNumber(user.getPhoneNumber()))
        {
            return ResponseEntity.badRequest().body("Invalid phone number");
        }

        User createdUser = userService.createUser(user);

        if (createdUser != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
        } else {
            return ResponseEntity.badRequest().body("Failed to create user");
        }

    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        // You can implement your validation logic here
        // For simplicity, we'll assume any non-empty phone number is valid
        return phoneNumber.length() == 10;
    }
}
